N = int(input("Nhap vao so diem cua hoc sinh:"))
if N >= 8.5:
    print(f"xep hang A")
elif N >= 7:
    print(f"xep hang B")
elif N >= 5:
    print(f"xep hang C")
else:
    print(f'xep hang D')