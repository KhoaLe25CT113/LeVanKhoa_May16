N = int(input("Nhap vao so tuoi cua 1 nguoi: "))
if N < 12:
    ket_qua = f"N = {N}la \"Tre em\"."
elif N <= 17:
    ket_qua = f"N = {N}la \"Thieu nien\"."
elif N <=59:
    ket_qua = f"N ={N}la \"Nguoi truong thanh\"."
else:
    ket_qua = f"N ={N}la \"Nguoi cao tuoi\"."
print(ket_qua)