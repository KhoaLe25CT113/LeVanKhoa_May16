N = int(input("Nhap so Kw dien da su dung trong thang: "))
if N <= 100:
    print(f"so tien dien la:{N*2000}")
elif N <= 200:
    print(f"so tien dien la:{100*2000+(N-100)*3000}")
else:
    print(f"so tien dien la:{100*2000+100*3000+(N-200)*4000}")