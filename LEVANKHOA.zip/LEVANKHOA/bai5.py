CN = int(input("Nhap can nang"))
CC = int(input("Nhap chieu cao"))
BMI = CN / (CC^2)
if BMI < 18.5:
    print(f"Gay")
elif BMI <= 24.9:
    print(f"Binh thuong")
elif BMI <=29.9:
    print(f"Thua can")
else:
    print(f"Beo phi")