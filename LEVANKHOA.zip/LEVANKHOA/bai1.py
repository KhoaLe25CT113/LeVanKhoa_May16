N = int(input("Nhap so nguyen N: "))
if N > 0:
    ket_qua = f"N = {N} la \"so duong\"."
elif N < 0:
    ket_qua = f"N = {n} la \"so am\"."
else: # N == 0:
    ket_qua = f"N = {N} la \"so 0\"."
print(ket_qua)
